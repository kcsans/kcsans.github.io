﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC2_KCS_SumCalculator
{
    public partial class SumCalculatorForm : Form
    {
        public SumCalculatorForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //this means the "form"
            // close is a command, which ends in ()
            // all lines end in ;
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            xTextBox.Clear();
            yTextBox.Clear();
            //The double quotes indicate an empty string to clear label.
            sumLabel.Text = "";
            xTextBox.Focus();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Preparation: Data Dictionary
            double x;
            double y;
            double sum;
            //Read from the textboxs appropriate to the variable.
            x = Convert.ToDouble(xTextBox.Text);
            y = Convert.ToDouble(yTextBox.Text);
            //Process: Add x + y = sum
            sum = x + y;
            //If you can read this, you can read C#!
            //I/O: Display sum to sumLabel
            sumLabel.Text = Convert.ToString(sum);
//woot! we did the hardest part!
            xTextBox.Focus();
            xTextBox.SelectAll();
            //Done?
            //Confirmed run! We are Done Son!
        }
    }
}
